public class Umban_Class {

    private int StudentNo = 0;
    private String Fname = null;
    private String Lname = null;
    private String Course = null;


public int getStudentNo(){
   return this.StudentNo;
 }  
public String getFname(){
   return this.Fname;
}
public String getLname(){
   return this.Lname;
 }  
public String getCourse(){
   return this.Course;
   }


public void setStudentNo(int sn){
    this.StudentNo = sn;
}
public void setFname(String fn){
    this.Fname = fn;
}
public void setLname(String ln){
    this.Lname = ln;
}
public void setCourse(String c){
    this.Course = c;  
}

    public static void main(String[] args) {
         Umban_Class Student = new Umban_Class();
         
        Student.setStudentNo(201420553);
        Student.setFname("John Dave");
        Student.setLname("Umban");
        Student.setCourse("BCS21");
        
        System.out.println("Student Number: " + Student.getStudentNo());
        System.out.println("First Name: " + Student.getFname());
        System.out.println("Last Name: " + Student.getLname());
        System.out.println("Course: "+ Student.getCourse());
    }
    
}
