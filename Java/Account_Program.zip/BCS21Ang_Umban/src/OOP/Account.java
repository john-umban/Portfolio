/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package OOP;

/**
 *
 * @author Faculty
 */
public class Account {
    
    private String accName;    
    int acctNum;
    String name;
    double balance;
    public static double minBal = 5000;
    static int num = 1000;

    
    //////////////////////////////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// 
    public void setName (String name){this.accName = name;}
    public String getName() { return this.accName;}
    
    public void setBalance (double balance){ this.balance = balance; }
    public double getBalance() { return this.balance;}
    
    public int getaccNum () {return this.acctNum;}
    
    
    
    
    public String toString (){
        return "\n Account Number: " + this.acctNum + "\n Account Name: " + this.accName + "\n Account Balance: " + this.balance; 
    }
    
    public void setBal(double bal){
        this.balance = bal;
    }
    
    public double deposit (double amount){
        balance = this.balance + amount;  
        return balance;
    } 
    
    public double withdraw (double amount){
        balance = this.balance - amount;
        return balance;
    }
    
    public static double getMinBal(){
        return minBal;
    }
 ////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// ////////////////////////// 
    
  
    public Account(String name, double balance){
        
        if (balance >= this.minBal)
            this.balance = balance;
        else
            this.balance = minBal;
        this.accName = name;
        num++;
        this.acctNum = num;
        this.acctNum = num;
        this.name = name;
        this.balance = balance;
        
      
    } void deposit(){
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
   