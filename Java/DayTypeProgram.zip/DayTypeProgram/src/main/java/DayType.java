/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class DayType {
            
    private String day;
    
    public DayType(){
        this.day = "Sun";
    }
    
    public void setDay(String sday){
        this.day = sday; 
    }
    
    public DayType(String sday){
        setDay(sday);
    }        

    public String next(){        
            switch (day) 
               {
                  case "Sun":
                        return "Mon";
                  case "Mon":
                        return "Tue";
                  case "Tue":
                        return "Wed";
                  case "Wed":
                        return "Thu";
                  case "Thu":
                        return "Fri";
                  case "Fri":
                        return "Sat";
                  case "Sat":
                        return "Sun";
                }
                  return "";
    }   
    
    public String previous(){
            switch (day) 
               {
                  case "Sun":
                        return "Sat";
                  case "Mon":
                        return "Sun";
                  case "Tue":
                        return "Mon";
                  case "Wed":
                        return "Tue";
                  case "Thu":
                        return "Wed";
                  case "Fri":
                        return "Thu";
                  case "Sat":
                        return "Fri";
                }
                  return "";
    }
    
    public String add(int Day){                
        int newDay;    
        switch (this.day) 
               {
                  case "Sun":
                      newDay = ((0 + Day)%7); 
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                  case "Mon":
                      newDay = ((1 + Day)%7); 
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                  case "Tue":
                      newDay = ((2 + Day)%7); 
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                  case "Wed":
                      newDay = ((3 + Day)%7);
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                  case "Thu":
                      newDay = ((4 + Day)%7);
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                  case "Fri":
                      newDay = ((5 + Day)%7); 
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                  case "Sat":
                      newDay = ((6 + Day)%7); 
                      switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Sun";
                      }
                }        
                  return "";
        
    }
    
    public String minus(int numDay){
            int newDay;
                  switch (this.day) 
               {
                  case "Sun":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Sun";
                          case 1:
                              return "Sat";
                          case 2:
                              return "Fri";
                          case 3:
                              return "Thu";
                          case 4:
                              return "Wed";
                          case 5:
                              return "Tue";
                          case 6:
                              return "Mon";
                          case 7:
                              return "Sun";
                      }
                  
                  case "Mon":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Mon";
                          case 1:
                              return "Sun";
                          case 2:
                              return "Sat";
                          case 3:
                              return "Fri";
                          case 4:
                              return "Thu";
                          case 5:
                              return "Wed";
                          case 6:
                              return "Tue";
                          case 7:
                              return "Mon";
                      }

                  case "Tue":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Tue";
                          case 1:
                              return "Mon";
                          case 2:
                              return "Sun";
                          case 3:
                              return "Sat";
                          case 4:
                              return "Fri";
                          case 5:
                              return "Thu";
                          case 6:
                              return "Wed";
                          case 7:
                              return "Tue";
                      }

                  case "Wed":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Wed";
                          case 1:
                              return "Tue";
                          case 2:
                              return "Mon";
                          case 3:
                              return "Sun";
                          case 4:
                              return "Sat";
                          case 5:
                              return "Fri";
                          case 6:
                              return "Thu";
                          case 7:
                              return "Wed";
                      }

                  case "Thu":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Thu";
                          case 1:
                              return "Wed";
                          case 2:
                              return "Tue";
                          case 3:
                              return "Mon";
                          case 4:
                              return "Sun";
                          case 5:
                              return "Sat";
                          case 6:
                              return "Fri";
                          case 7:
                              return "Thu";
                      }

                  case "Fri":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Fri";
                          case 1:
                              return "Thu";
                          case 2:
                              return "Wed";
                          case 3:
                              return "Tue";
                          case 4:
                              return "Mon";
                          case 5:
                              return "Sun";
                          case 6:
                              return "Sat";
                          case 7:
                              return "Fri";
                      }

                  case "Sat":
                        newDay = ((0 - numDay)%7);
                        switch (newDay)
                      {
                          case 0:
                              return "Sat";
                          case 1:
                              return "Fri";
                          case 2:
                              return "Thu";
                          case 3:
                              return "Wed";
                          case 4:
                              return "Tue";
                          case 5:
                              return "Mon";
                          case 6:
                              return "Sun";
                          case 7:
                              return "Sat";
                      }

                }
                  return "";
    }

}       